package com.ssafy.board.model;

public class CommentDto {

	private int commentNo;
	private String userId;
	private String userName;
	private String comment;
	private String registerTime;
	private int articleNo;
	private String userImgUrl;
	
	
	@Override
	public String toString() {
		return "CommentDto [commentNo=" + commentNo + ", userId=" + userId + ", userName=" + userName + ", comment="
				+ comment + ", registerTime=" + registerTime + ", articleNo=" + articleNo + ", userImgUrl=" + userImgUrl
				+ "]";
	}
	public String getUserImgUrl() {
		return userImgUrl;
	}
	public void setUserImgUrl(String userImgUrl) {
		this.userImgUrl = userImgUrl;
	}
	public int getCommentNo() {
		return commentNo;
	}
	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(String registerTime) {
		this.registerTime = registerTime;
	}
	public int getArticleNo() {
		return articleNo;
	}
	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}
}
